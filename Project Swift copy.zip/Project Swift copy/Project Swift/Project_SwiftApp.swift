//
//  Project_SwiftApp.swift
//  Project Swift
//
//  Created by Admin on 15/6/2567 BE.
//

import SwiftUI

@main
struct Project_SwiftApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
