//
//  Admin.swift
//  Project Swift
//
//  Created by Admin on 15/6/2567 BE.
//

import SwiftUI


struct Admin: View {
    var body: some View {
        Text("\(Data[1].name1)")
    }
}

#Preview {
    Admin()
}
